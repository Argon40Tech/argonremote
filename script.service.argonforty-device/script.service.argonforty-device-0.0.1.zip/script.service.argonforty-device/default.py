# -*- coding: utf-8 -*-
from resources.lib import kodiutils


kodiutils.show_settings()

